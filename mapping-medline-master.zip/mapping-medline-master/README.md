# mapping-medline
This is a mash-up of Google Charts and the NCBI API (plus a little math) to display a PubMed search as a choropleth map showing the proportion of results of that search for each country.

See it in action at: http://esperr.github.io/mapping-medline/

For more PubMed visualization fun, be sure to check out https://github.com/esperr/mesh-cat-graph, https://github.com/esperr/mesh-subhead-graph and  https://github.com/esperr/pubvenn
