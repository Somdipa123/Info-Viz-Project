#!/usr/bin/env python
# coding: utf-8

# In[ ]:


world_geo = r'world_countries.json' # geojson file
 
 # create a plain world map
 world_map = folium.Map(location=[0, 0], zoom_start=2, tiles='Mapbox Bright')
 
 # generate choropleth map using the total immigration of each country to Canada from 1980 to 2013
 world_map.choropleth(
     geo_data=world_geo,
     data=df_can,
     columns=['Country', 'Total'],
     key_on='feature.properties.name',
     fill_color='YlOrRd', 
     fill_opacity=0.7, 
     line_opacity=0.2,
     legend_name='Proportion of Medline Citations for Stomach Cancer in Asia'
 )
 
 # display map
 world_map
 world_geo = r'world_countries.json'
 
 # create a numpy array of length 6 and has linear spacing from country names
 threshold_scale = np.linspace(df_can['Total'].min(),
                               df_can['Total'].max(),
                               6, dtype=int)
 threshold_scale = threshold_scale.tolist() # change the numpy array to a list
 threshold_scale[-1] = threshold_scale[-1] + 1 
 
 # let Folium determine the scale.
 world_map = folium.Map(location=[0, 0], zoom_start=2, tiles='Mapbox Bright')
 world_map.choropleth(
     geo_data=world_geo,
     data=df_can,
     columns=['Country', 'Total'],
     key_on='feature.properties.name',
     threshold_scale=threshold_scale,
     fill_color='YlOrRd', 
     fill_opacity=0.7, 
     line_opacity=0.2,
     legend_name=' Proportion of Wine vs Beer in Medline',
     reset=True
 )
 

